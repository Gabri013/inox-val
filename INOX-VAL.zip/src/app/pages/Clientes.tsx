import { ClientesList } from '@/domains/clientes';

export default function Clientes() {
  return <ClientesList />;
}