import { ProdutosList } from '@/domains/produtos';

export default function Produtos() {
  return <ProdutosList />;
}