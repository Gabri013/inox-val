// Placeholder (não implementar nesta etapa)

