// Simple test to verify Vitest is working
import { describe, it, expect } from 'vitest';

describe('Simple Test', () => {
  it('should run a basic test', () => {
    expect(1 + 1).toEqual(2);
  });
});
