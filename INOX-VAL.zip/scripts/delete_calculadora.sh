#!/bin/bash
# Script para remover toda a pasta calculadora do domínio
rm -rf src/domains/calculadora
rm -f src/app/pages/Calculadora.tsx
